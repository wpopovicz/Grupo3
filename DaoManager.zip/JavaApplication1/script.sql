

DROP DATABASE IF EXISTS aluno;
CREATE DATABASE aluno;
USE aluno;


CREATE TABLE pessoa ( 
  id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  nome varchar(100) NOT NULL,
  cpf varchar(15) NOT NULL);

CREATE TABLE municipio ( 
  id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  nome varchar(100) NOT NULL,
  uf char(2) NOT NULL);

CREATE TABLE endereco (
  end_pessoa int not null,
  logradouro varchar(200),
  numero smallint,
  complemento varchar(100),
  municipio int,
  FOREIGN KEY (end_pessoa) REFERENCES pessoa(id) ON DELETE CASCADE,
  FOREIGN KEY (municipio) REFERENCES municipio(id) ON DELETE CASCADE
);

START TRANSACTION;

INSERT INTO pessoa (id, nome, cpf) VALUES(null, 'Eduardo', '0000000011');
SET @ID_PESSOA := LAST_INSERT_ID();
INSERT INTO municipio (id, nome, uf) VALUES(null, 'Campo Mourão', 'PR');
SET @ID_MUNICIPIO := LAST_INSERT_ID();
INSERT INTO endereco (end_pessoa, logradouro, numero, complemento, municipio) VALUES(@ID_PESSOA, 'Rua brasil', 123, 'esquina', @ID_MUNICIPIO);
INSERT INTO pessoa (id, nome, cpf) VALUES(null, 'Raphael', '0000000011');
SET @ID_PESSOA := LAST_INSERT_ID();
INSERT INTO endereco (end_pessoa, logradouro, numero, complemento, municipio) VALUES(@ID_PESSOA, 'Rua Araruna', 123, 'esquina', @ID_MUNICIPIO);

COMMIT;