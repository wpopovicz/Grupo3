/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1.entidades;

/**
 *
 * @author lgvalentin
 */
public class Endereco {
    private int id;
    private String logradouro;
    private int numero;
    private String complemento;


    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return "Endereco{" + "id=" + id + ", logradouro=" + logradouro + ", numero=" + numero + '}';
    }

}
