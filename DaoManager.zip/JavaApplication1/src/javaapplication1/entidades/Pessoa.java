/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1.entidades;

import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author lgvalentin
 */
public class Pessoa {
    private int id;
    public static String nome;
    protected String cpf;
    private Date dataNascimento = Calendar.getInstance().getTime();
    
    private Endereco endereco;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        if(dataNascimento == null)
                throw new RuntimeException("A data de masco,emtp [e fdoufdskhfdlk hliudf gkdjhg kdj");
        
        this.dataNascimento = dataNascimento;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "id=" + id + ", nome=" + nome + ", cpf=" + cpf + '}';
    }

}
