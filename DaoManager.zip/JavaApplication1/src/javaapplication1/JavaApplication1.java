/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.awt.GridLayout;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import javaapplication1.entidades.Pessoa;
import javaapplication1.daos.DaoPessoa;
import java.sql.SQLException;
import javaapplication1.entidades.Endereco;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author lgvalentin
 */
public class JavaApplication1 {

    public static void show(Object obj) throws Exception {
        JDialog dialog = new JDialog();
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setLayout(new GridLayout(0, 2));
        dialog.setModal(true);
        dialog.setSize(400, 400);

        dialog.setTitle(obj.getClass().getSimpleName());

        for (Method m : obj.getClass().getMethods()) {
            if (m.getName().startsWith("get") && m.getDeclaringClass() != Object.class) {
                System.out.println("----" + m.getName());
                JLabel l = new JLabel(m.getName());
                JTextField t = new JTextField();
                t.setText(m.invoke(obj) + "");
                dialog.add(l);
                dialog.add(t);
            }
        }

        dialog.setVisible(true);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {




        Pessoa p = new Pessoa();
        p.setNome("Lucio");
        p.setCpf("0000000000");

        System.out.println("--->" + p.getClass().getDeclaredFields().length);
        for (Field f : Pessoa.class.getDeclaredFields()) {
            System.out.println("-----" + f.getName() + "=====" + f.getType() + ":"
                    + f.getModifiers());
            if (Modifier.isPublic(f.getModifiers())) {
                System.out.println("PUBLICOOOOOOOOOOOo");
            }
            if (Modifier.isPrivate(f.getModifiers())) {
                System.out.println("PR%IVASTTEEEEE");
            }

        }



        show(p);

        Endereco e = new Endereco();
        e.setLogradouro("Log");

        show(e);

    }
}
