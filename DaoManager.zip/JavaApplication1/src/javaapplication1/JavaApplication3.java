/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import javaapplication1.entidades.Pessoa;
import javaapplication1.daos.DaoPessoa;
import java.sql.SQLException;

/**
 *
 * @author lgvalentin
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        DaoPessoa dp = new DaoPessoa();
        
        Pessoa p = new Pessoa();
        p.setNome("Lucio");
        p.setCpf("1111111111");
        System.out.println("BEFORE INSERT:" + p);   
        dp.persist(p);
        System.out.println("INSERT:" + p);   
        
        p.setNome(p.getNome() + "zzz");
        dp.persist(p);
        System.out.println("UPDATE:" + p);   
        p = dp.retrieve(2);
        System.out.println("RETRIEVE:" + p);   
        
        
        for(Pessoa p1: dp.list()){
            System.out.println("LIST:" + p1);   
        }
    }
}
