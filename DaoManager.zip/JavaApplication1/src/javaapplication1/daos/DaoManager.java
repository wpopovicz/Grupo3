/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1.daos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javaapplication1.entidades.Endereco;
import javaapplication1.entidades.Pessoa;

/**
 *
 * @author lgvalentin
 */
public class DaoManager{
    
    private static final Map<Class, Dao> daos = new HashMap<Class, Dao>();
    
    static{
        daos.put(Pessoa.class, new DaoPessoa());
        daos.put(Endereco.class, new DaoEndereco());
    }
    

    private static Dao obtemDao(Class co) throws IllegalAccessException, InstantiationException, ClassNotFoundException {
        return daos.get(co);
    }

    public static void persist(Object o) throws Exception {
        Dao daoObject = obtemDao(o.getClass());
        
        daoObject.persist(o);
    }

    public void delete(Object o) throws Exception {
        Dao daoObject = obtemDao(o.getClass());
        
        daoObject.delete(o);
    }

    public Object retrieve(Class tipoObjeto, int id) throws Exception {
        Dao daoObject = obtemDao(tipoObjeto);
        
        return daoObject.retrieve(id);
    }

    public List list(Class tipoObjeto) throws Exception {
        Dao daoObject = obtemDao(tipoObjeto);
        
        return daoObject.list();
    }    
}
